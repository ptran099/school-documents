/*
Problem 1.4
Find names and addresses of all subscribers who subscribe to all services.
*/

SELECT name,address FROM subscribers
JOIN service_subscribers ON subscribers.portid = service_subscribers.portid
GROUP BY subscribers.portid, name, address
HAVING COUNT(DISTINCT service_subscribers.service) = (SELECT DISTINCT count(scode) FROM services);

/*
Test Output:
*/