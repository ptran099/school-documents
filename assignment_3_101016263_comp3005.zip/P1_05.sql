/*
Problem 1.5
Find names of all subscribers subscribed to at least 3 services
*/

SELECT name FROM subscribers
JOIN service_subscribers ON subscribers.portid=service_subscribers.portid
GROUP BY subscribers.portid,name
HAVING COUNT(DISTINCT service_subscribers.service) >= 3

/*
Test Output:
name
--------------
Chris Pronger
Frank Thomas
Homer Simpson
Joe Carter
Matt Stajan
Michael Jordan
Steve Sampras
Vince Carter
*/
