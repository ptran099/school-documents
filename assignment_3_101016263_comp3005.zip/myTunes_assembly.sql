PRAGMA foreign_keys=OFF;

-- idempotence
DROP TABLE IF EXISTS cds_staging;
DROP TABLE IF EXISTS songs_staging;
DROP TABLE IF EXISTS cds;
DROP TABLE IF EXISTS songs;
.read myTunes_Abdelghny.sql
-- rename tables into stqaging tables
ALTER TABLE cds RENAME TO cds_staging;
ALTER TABLE songs RENAME TO songs_staging;

DROP TABLE IF EXISTS cds;
DROP TABLE IF EXISTS songs;
.read myTunes_Ali.sql
-- copy data to staging tables
INSERT OR IGNORE INTO cds_staging (cd_id, title, artist, producer, year, contributer) SELECT cd_id, title, artist, producer, year, contributer FROM cds;
-- song_id is autoincrementing
INSERT INTO songs_staging (title, composer, cd_id, track, contributer) SELECT title, composer, cd_id, track, contributer FROM songs;

DROP TABLE IF EXISTS cds;
DROP TABLE IF EXISTS songs;
.read myTunes_Fatemeh.sql
INSERT OR IGNORE INTO cds_staging (cd_id, title, artist, producer, year, contributer) SELECT cd_id, title, artist, producer, year, contributer FROM cds;
INSERT INTO songs_staging (title, composer, cd_id, track, contributer) SELECT title, composer, cd_id, track, contributer FROM songs;

DROP TABLE IF EXISTS cds;
DROP TABLE IF EXISTS songs;
.read myTunes_Monica.sql
INSERT OR IGNORE INTO cds_staging (cd_id, title, artist, producer, year, contributer) SELECT cd_id, title, artist, producer, year, contributer FROM cds;
INSERT INTO songs_staging (title, composer, cd_id, track, contributer) SELECT title, composer, cd_id, track, contributer FROM songs;

DROP TABLE IF EXISTS cds;
DROP TABLE IF EXISTS songs;
.read myTunes_Rezieh.sql
INSERT OR IGNORE INTO cds_staging (cd_id, title, artist, producer, year, contributer) SELECT cd_id, title, artist, producer, year, contributer FROM cds;
INSERT INTO songs_staging (title, composer, cd_id, track, contributer) SELECT title, composer, cd_id, track, contributer FROM songs;

DROP TABLE IF EXISTS cds;
DROP TABLE IF EXISTS songs;
.read myTunes_Saman.sql
INSERT OR IGNORE INTO cds_staging (cd_id, title, artist, producer, year, contributer) SELECT cd_id, title, artist, producer, year, contributer FROM cds;
INSERT INTO songs_staging (title, composer, cd_id, track, contributer) SELECT title, composer, cd_id, track, contributer FROM songs;

-- drop tables to make availability for final tables
DROP TABLE IF EXISTS cds;
DROP TABLE IF EXISTS songs;

-- rename staging tables into final table names
ALTER TABLE cds_staging RENAME TO cds;
ALTER TABLE songs_staging RENAME TO songs;