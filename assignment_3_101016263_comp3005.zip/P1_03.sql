/*
Problem 1.3
List the names of all subscribers who are the originators of a call to someone who is a subscriber on the same switch
(i.e the originators of a line to line call).
*/

SELECT name FROM subscribers
JOIN (
    SELECT orig, term FROM calls
    WHERE orig IN (SELECT portid FROM lines)
    AND term IN (SELECT portid FROM lines)
) ON subscribers.portid = orig;

/*
Test Output:
name
--------------
Mats Sundin
Jason Allison
Homer Simpson
Michael Jordan
Ed Belfour
*/