/*
Problem 1.10
List the name of all service-subscribers that subscribe to at least
all the same services as Jason Allison subscribes to but possibly
other services as well. Jason Allison rents the line with portID=2.
(So this is the classic "subset" query, we're looking for people
whose services are a superset of Jason Allison's services).
*/

SELECT name FROM subscribers 
JOIN service_subscribers 
ON subscribers.portid = service_subscribers.portid
WHERE service IN (
    SELECT service FROM SERVICE_SUBSCRIBERS WHERE portid = 2
) 
GROUP BY subscribers.portid
HAVING COUNT(DISTINCT service) = (
    SELECT COUNT(DISTINCT service) FROM service_subscribers
    WHERE portid = 2
);

/*
Test Output:
name
--------------
Jason Allison
Michael Jordan
Joe Carter
Homer Simpson
Matt Stajan
*/