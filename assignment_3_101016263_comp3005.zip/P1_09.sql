/*
Problem 1.9
Same as Question 1.7 but this time only include trunks that have
at least one 'IDLE' channel. In 1 table, make a list of all
acceptable trunks that can be used to route a call to the 416
area code, office code 334 have at least one idle channel.
List the trunks in order of preference (list trunk routes 416,334
then 416,000 then 000,000 for example).
*/

SELECT channels.portid, trunks.foreign_switch, trunk_routes.area, trunk_routes.office FROM channels
    JOIN trunks ON channels.portid=trunks.portid
    JOIN trunk_routes ON channels.portid=trunk_routes.portid
        WHERE (
            (area='416' AND office='334') OR
            (area='416' AND office='000') OR
            (area='000' AND office='000')
        ) AND channels.state='IDLE'
        GROUP BY
            channels.portid, trunks.foreign_switch, trunk_routes.area, trunk_routes.office
        ORDER BY
        CASE
            WHEN trunk_routes.area='416' AND trunk_routes.office='334' THEN 1
            WHEN trunk_routes.area='416' AND trunk_routes.office='000' THEN 2
            ELSE 3
        END

/*
Test Output:
portid  foreign_switch  area  office
------  --------------  ----  ------
102     RIDEAU          416   334
102     RIDEAU          416   000
106     BAY             416   000
107     Innes           000   000
*/