/*
Problem 1.7
Make a list of all trunks that can be used to route a call to
(416) 334-XXXX (that is, 416 area code, 334 office code)
List trunks in order of preference (answer should list trunks with routes 416,334
then those with 416,000 and finally those with 000,000 for example).
*/

SELECT trunk_routes.portid, foreign_switch, trunk_routes.area, trunk_routes.office FROM trunks JOIN trunk_routes
ON trunks.portid = trunk_routes.portid
WHERE (area='416' AND office='334') OR (area='416' AND office='000') OR (area='000' AND office='000') 
ORDER BY trunk_routes.area DESC, trunk_routes.office DESC;

/*
Test Output:
portid  foreign_switch  area  office
------  --------------  ----  ------
102     RIDEAU          416   334
102     RIDEAU          416   000
106     BAY             416   000
107     Innes           000   000
*/