/*
Problem 1.6
Table with the most popular service(s), the name of the service that has the most 
subscribers subscribing to the service.
*/

SELECT service, count(service) AS subscriber_count1 FROM service_subscribers
GROUP BY service
HAVING subscriber_count1 = (
    SELECT MAX(subscriber_count2)
    FROM (select count(service) AS subscriber_count2
        FROM service_subscribers GROUP BY service)
    );

/*
Test Output:
service  subscriber_count1
-------  -----------------
MSG      25
*/