/*
Problem 1.8
Find if the line with phone number (613) 712-0024 is currently available to take
a call because its channel is IDLE. That is, select portid, directory number,
and channel state of line (613) 712-0024
*/
SELECT lines.portid, areacode || '-' || officecode || '-' || stationcode AS directory_number, state AS channel_state
    FROM lines JOIN channels ON lines.portid=channels.portid
    WHERE areacode='613' AND officecode='712' AND stationcode='0024' AND channel='0';
/*
Test Output:
portid  directory_number  channel_state
------  ----------------  -------------
24      613-712-0024      BUSY
*/