changeTimeOfDay(day, night).
changeTimeOfDay(night, day).


% edge associated with "leaping"
transition(state(DistanceBefore, TimeBefore), state(DistanceAfter, TimeAfter), leap) :- 
	DistanceAfter is DistanceBefore - 3,
	TimeBefore \= night,
	changeTimeOfDay(TimeBefore, TimeAfter).
	
% edges associated with "resting"
transition(state(DistanceBefore, TimeBefore), state(DistanceAfter, TimeAfter), rest) :- 
	DistanceAfter is DistanceBefore + 2,
	DistanceAfter =< 5,
	changeTimeOfDay(TimeBefore, TimeAfter).

% bottom of the well 	
transition(state(DistanceBefore, TimeBefore), state(5, TimeAfter), rest) :- 
	DistanceBefore > 3,
	changeTimeOfDay(TimeBefore, TimeAfter).


% base case for escaping the well
escapeTheWell(state(CurrentDistance, _), []) :- CurrentDistance =< 0.

% recursive case for escaping the well
escapeTheWell(state(CurrentDistance, CurrentTime), [Action | Strategy]) :-
	CurrentDistance > 0,
	transition(state(CurrentDistance, CurrentTime), state(NextDistance, NextTime), Action),
	escapeTheWell(state(NextDistance, NextTime), Strategy).
	
