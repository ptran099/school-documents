% these are the only VALID configuations of the boat...
% you *could* replace this with a rule
passengers(0, 2).
passengers(1, 1).
passengers(2, 0).
passengers(1, 0).
passengers(0, 1).

% transition(
%	state(CanEastBefore, MisEastBefore, CanWestBefore, MisWestBefore, east), 	
%	crossEtoW(NumCan, NumMis),
%	state(CanEastAfter, MisEastAfter, CanWestAfter, MisWestAfter, west)) :- ...

% 'is' is the Prolog assignment operator
% <- , = 
% it literally means "evaluate the RHS and instantiate the LHS variable to that value"

transition( state(A, B, C, D, east), cross(I, J), state(W, X, Y, Z, west) ) :-
	passengers(I, J), % instantiating I and J to valid numbers of cannibals and missionaries (for the boat)
	W is A-I, W >= 0, % reducing the number of cannibals on the east side BUT not below ZERO
	X is B-J, X >= 0, % reducing the number of missionaries on the east side BUT not below ZERO
	Y is C+I, % increasing the number of cannibals on the west (by the number that were moved east to west)
	Z is D+J, % increasing the number of missionaries on the west (by the number that were moved east to west)
	safe(W, X, Y, Z). % I needed a "is this new state a *permitted* one" predicate

transition( state(A, B, C, D, west), cross(I, J), state(W, X, Y, Z, east) ) :- passengers(I, J), W is A+I, X is B+J, Y is C-I, Y >= 0, Z is D-J, Z >= 0, safe(W, X, Y, Z).

safe(A, B, C, D) :-
	(A =< B ; B == 0), % cannibals on the east can't outnumber missionaries on the east, or no missionaries left on the east
	(C =< D ; D == 0). % cannibals on the west can't outnumber missionaries on the west, or no missionaries left on the west

crossSafely(S, S, []).
crossSafely(S, E, [X | Y]) :- S \= E, transition(S, X, I), crossSafely(I, E, Y).

find_solution() :- length(L, 11), crossSafely(state(3, 3, 0, 0, east), state(0, 0, 3, 3, _), L), write(L).