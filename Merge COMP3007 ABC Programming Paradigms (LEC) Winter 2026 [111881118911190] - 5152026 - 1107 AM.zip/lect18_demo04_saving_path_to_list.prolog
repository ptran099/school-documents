edge(1,2).
edge(2,4).
edge(1,3).
edge(3,5).
edge(5,6).
edge(3,6).

is_there_a_path(X, Y) :- edge(X, Y).
is_there_a_path(X, Y) :- edge(X, Z), is_there_a_path(Z, Y).

what_is_the_path(X, Y, [(X, Y)] ) :- edge(X, Y).
what_is_the_path(X, Y, [(X, Z) | A]) :- edge(X, Z), what_is_the_path(Z, Y, A).
