
% taking the banana
transition(state(atCenter, onBox, atCenter, hasNot), take, state(atCenter, onBox, atCenter, has)).

% climbing on top of the box
transition(state(WhereIsMonkey, onFloor, WhereIsMonkey, hasNot), climb, state(WhereIsMonkey, onBox, WhereIsMonkey, hasNot)).

% lifting the box from one place to another
transition(state(WhereIsMonkeyBefore, onFloor, WhereIsMonkeyBefore, hasNot), lift(WhereIsMonkeyBefore, WhereIsMonkeyAfter), state(WhereIsMonkeyAfter, onFloor, WhereIsMonkeyAfter, hasNot)).

% walking around the room
transition(state(WhereIsMonkeyBefore, onFloor, WhereIsBox, hasNot), walk(WhereIsMonkeyBefore, WhereIsMonkeyAfter), state(WhereIsMonkeyAfter, onFloor, WhereIsBox, hasNot)).


getTheBanana(state(_, _, _, has), []).

getTheBanana(CurrentState, [Action | Strategy]) :- 
	transition(CurrentState, Action, NewState),
	getTheBanana(NewState, Strategy).