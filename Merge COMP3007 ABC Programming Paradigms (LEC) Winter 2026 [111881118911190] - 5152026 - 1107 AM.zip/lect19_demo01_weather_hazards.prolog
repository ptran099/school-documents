weather(wednesday, rain).
weather(thursday, sun).
weather(friday, snow).
weather(saturday, sun).
teaching(wednesday, early).
teaching(thursday, late).
teaching(friday, early).
teaching(friday, late).
teaching(saturday, none).

walkToWork(Day) :- weather(Day, X), X \= rain, teaching(Day, Y), Y \= early.
walkToWork(_) :- write("An alternative exists...").

walkToWork1(Day) :- weather(Day, X), !, X \= rain, teaching(Day, Y), Y \= early.
walkToWork2(Day) :- weather(Day, X), X \= rain, !, teaching(Day, Y), Y \= early.
walkToWork3(Day) :- weather(Day, X), X \= rain, teaching(Day, Y), !, Y \= early.
walkToWork4(Day) :- weather(Day, X), X \= rain, teaching(Day, Y), Y \= early, !.

walkToWork5(Day) :- !, weather(Day, X), X \= rain, teaching(Day, Y), Y \= early.
walkToWork5(_) :- write("An alternative exists...").

walkToWorkFinal(Day) :- check_weather(Day), check_teaching(Day).
check_weather(Day) :- weather(Day, X), X \= rain.
check_teaching(Day) :- teaching(Day, Y), !, Y \= early.