is_n(_, Upper) :- Upper =< 0, !, fail.
is_n(0, _).
is_n(X, Upper) :- is_n(Y, Upper), X is Y + 1, (X < Upper; X >= Upper, !).

% The cut predicate used in line 3 is being used to control backtracking,
% essentially preventing backtracking when this process would start generating
% numbers larger that the upper bound. It should probably be noted that there
% are other ways to do this, with the most obvious one being that we could reduce
% the upper bound on the recursive call, but I think this one is probably the
% most intuitive and relevant to what we were recently discussing in class!

