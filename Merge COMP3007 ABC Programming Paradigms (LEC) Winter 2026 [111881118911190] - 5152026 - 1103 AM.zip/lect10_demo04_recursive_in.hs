-- in' :: [a] -> a -> Bool         -- this doesn't work because no guarantee that a is something you can do an equality test on
in' :: (Eq a) => [a] -> a -> Bool  -- but if I add this constraint that a must be "equatable" then it will work

in' [] _ = False

in' (h:t) x 
  | h == x = True
  | otherwise = (in' t x)