tripleSum :: [Int] -> [Int]
tripleSum [] = []
tripleSum (x:y:z:t) = (x + y + z) : (tripleSum t)
tripleSum x = [] -- what happens if you add this and try tripleSum [1,2,3,4,5,6,7,8,9]?
-- And then tripleSum [1,2,3,4,5,6,7,8,9,10]? See how it ignores the extraneous element?
