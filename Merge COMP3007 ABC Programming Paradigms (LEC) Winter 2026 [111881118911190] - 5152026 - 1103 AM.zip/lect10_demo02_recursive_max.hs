max' :: [Int] -> Int
max' (h:[]) = h
--max' (h:t)
--  | (max' t) > h = (max' t)
--  | otherwise = h

max' (h:t) = (greaterOf h (max' t))
  
greaterOf :: Int -> Int -> Int
greaterOf x y
  | x > y = x
  | otherwise = y