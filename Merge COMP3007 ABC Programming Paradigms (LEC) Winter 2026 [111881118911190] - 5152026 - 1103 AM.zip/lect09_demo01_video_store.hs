type Client = Int
type Video = [Char]
type Rental = (Client, Video)
type Database = [Rental]

database :: Database
database = [ (763547, "The Thing"), (929845, "Escape from New York"), (929845, "The Thing"), (181014, "Big Trouble in Little China") ]

queryVideos :: [Rental] -> Client -> [Video]
queryVideos [] _ = []
queryVideos db who
  | (fst (head db)) == who = (snd (head db)) : queryVideos (tail db) who
  | otherwise = queryVideos (tail db) who

--ghci> queryVideos database 929845
--["Escape from New York","The Thing"]

queryVideos' :: [Rental] -> Client -> [Video]
queryVideos' [] _ = []
queryVideos' (h:t) who
  | (fst h) == who = (snd h) : queryVideos' t who
  | otherwise = queryVideos' t who

queryVideos'' :: [Rental] -> Client -> [Video]
queryVideos'' [] _ = []
queryVideos'' ((cli, vid) : t) who
  | cli == who = vid : queryVideos'' t who
  | otherwise = queryVideos'' t who

queryVideos''' :: [Rental] -> Client -> [Video]
queryVideos''' db who = [vid | (cli, vid) <- db, cli == who]
