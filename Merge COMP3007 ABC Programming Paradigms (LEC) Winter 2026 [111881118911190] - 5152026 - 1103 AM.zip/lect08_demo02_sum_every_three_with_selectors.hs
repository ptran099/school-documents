tripleSum :: [Int] -> [Int]
tripleSum x
  | length x < 3 = []
  | otherwise = (head x) + (head (tail x)) + (head (tail (tail x))) : (tripleSum (tail (tail (tail x))))