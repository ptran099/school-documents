foo :: [[Int]] -> [Int]
foo [] = []
foo (h:t)
  | (mod (length h) 2) == 1 = ((head h) : (foo t))
  | otherwise = foo t

-- try foo [[6,2,3,4,6,8], [3,2,8,3,7], [1,2,3], [9,8,7,6]]

bar :: [[Int]] -> [Int]
bar x = [head y | y <- x, mod (length y) 2 == 1]
-- try bar [[6,2,3,4,6,8], [3,2,8,3,7], [1,2,3], [9,8,7,6]]