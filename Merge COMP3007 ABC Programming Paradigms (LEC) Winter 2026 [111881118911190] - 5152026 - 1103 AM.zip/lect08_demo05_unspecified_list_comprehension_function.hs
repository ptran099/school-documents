foo :: [Integer] -> [Integer]
foo [] = []
foo (h:t) = (foo [x | x <- t, x <= h]) ++ [h] ++ (foo [x | x <- t, x > h])
