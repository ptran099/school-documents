square' :: [Int] -> [Int]
square' [] = []
square' (h:t) = (h ^ 2) : (square' t)