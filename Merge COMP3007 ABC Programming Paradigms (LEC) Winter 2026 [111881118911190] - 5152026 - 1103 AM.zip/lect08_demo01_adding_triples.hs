-- ...without pattern matching, using selector functions (that we write ourselves)

firstOfThree :: (Int, Int, Int) -> Int
firstOfThree (a, b, c) = a

secndOfThree :: (Int, Int, Int) -> Int
secndOfThree (a, b, c) = b

thirdOfThree :: (Int, Int, Int) -> Int
thirdOfThree (a, b, c) = c

sumOfThree :: (Int, Int, Int) -> (Int, Int, Int) -> (Int, Int, Int) 
sumOfThree x y = ((firstOfThree x + firstOfThree y), (secndOfThree x + secndOfThree y), (thirdOfThree x + thirdOfThree y))


-- ... or with pattern matching, a more fundamental (and elegant) approach

--sumOfThree :: (Int, Int, Int) -> (Int, Int, Int) -> (Int, Int, Int) 
--sumOfThree (a, b, c) (x, y, z) = (a + x, b + y, c + z)
