-- Peter Tran
-- 101016263
BEGIN TRANSACTION;
DROP TABLE IF EXISTS employee;
DROP TABLE IF EXISTS department;
DROP TABLE IF EXISTS dept_locations;
DROP TABLE IF EXISTS project;
DROP TABLE IF EXISTS works_on;
DROP TABLE IF EXISTS dependent;
CREATE TABLE employee (
    fname text not null,
    minit text,
    lname text not null,
    ssn text primary key not null,
    bdate text,
    address text,
    sex text,
    salary int,
    superssn text,
    dno int,
    foreign key(superssn) references employee (ssn),
    foreign key(dno) references department (dnumber)
);
insert into employee (fname,minit,lname,ssn,bdate,address,sex,salary,superssn,dno) VALUES('John', 'B', 'Smith', '123456789', '9-Jan-55', '731 Fondern', 'M', 30000, '333445555', 5);
insert into employee (fname,minit,lname,ssn,bdate,address,sex,salary,superssn,dno) VALUES('Franklin', 'T', 'Wong', '333445555', '8-Dec-45', '638 Voss', 'M', 40000, '888665555', 5);
insert into employee (fname,minit,lname,ssn,bdate,address,sex,salary,superssn,dno) VALUES('Alicia', 'J', 'Zelaya', '999887777', '19-Jul-58', '3321 Castle', 'F', 25000, '987987987', 4);
insert into employee (fname,minit,lname,ssn,bdate,address,sex,salary,superssn,dno) VALUES('Jennifer', 'S', 'Wallace', '987654321', '20-Jun-31', '291 Berry', 'F', 43000, '888665555', 4);
insert into employee (fname,minit,lname,ssn,bdate,address,sex,salary,superssn,dno) VALUES('Ramesh', 'K', 'Narayan', '666884444', '15-Sep-52', '975 Fire Oak', 'M', 38000, '333445555', 5);
insert into employee (fname,minit,lname,ssn,bdate,address,sex,salary,superssn,dno) VALUES('Joyce', 'A', 'English', '453453453', '31-Jul-62', '5631 Rice', 'F', 25000, '333445555', 5);
insert into employee (fname,minit,lname,ssn,bdate,address,sex,salary,superssn,dno) VALUES('Ahmad', 'V', 'Jabber', '987987987', '29-Mar-59', '980 Dallas', 'M', 25000, '987654321', 4);
insert into employee (fname,minit,lname,ssn,bdate,address,sex,salary,superssn,dno) VALUES('James', 'E', 'Borg', '888665555', '10-Nov-27', '450 Stone', 'M', 55000, '333445555', 1);
CREATE TABLE department (
    dname text not null,
    dnumber int primary key not null,
    mgrssn text not null,
    mgrstartdate text not null,
    foreign key(mgrssn) references employee (ssn)
);
insert into department (DNAME, DNUMBER, MGRSSN, MGRSTARTDATE) values('Research', 5, 333445555, '22-May-78');
insert into department (DNAME, DNUMBER, MGRSSN, MGRSTARTDATE) values('Administration', 4, 987654321, '1-Jan-85');
insert into department (DNAME, DNUMBER, MGRSSN, MGRSTARTDATE) values('Headquarters', 1, 888665555, '19-Jun-71');
CREATE TABLE dept_locations (
    dnumber int not null,
    dlocation text not null,
    primary key (dnumber,dlocation),
    foreign key(dnumber) references department (dnumber)
);
insert into dept_locations values(1, 'Houston');
insert into dept_locations values(4, 'Stafford');
insert into dept_locations values(5, 'Bellaire');
insert into dept_locations values(5, 'Sugarland');
insert into dept_locations values(5, 'Houston');
CREATE TABLE project (
    pname text not null,
    pnumber int primary key not null,
    plocation text not null,
    dnum int,
    foreign key(dnum) references department (dnumber)
);
insert into project values('ProductX',1,'Bellaire',5);
insert into project values('ProductY',2,'Sugarland',5);
insert into project values('ProductZ',3,'Houston',5);
insert into project values('Computerization',10,'Stafford',4);
insert into project values('Reorganization',20,'Houston',1);
insert into project values('NewBenefits',30,'Stafford',4);
CREATE TABLE works_on (
    essn text not null,
    pno int not null,
    hours real,
    primary key (essn,pno),
    foreign key(essn) references employee (ssn),
    foreign key(pno) references project (pnumber)
);
insert into works_on (essn,pno,hours) values('123456789',1,32.50);
insert into works_on (essn,pno,hours) values('123456789',2,7.50);
insert into works_on (essn,pno,hours) values('666884444',3,40.00);
insert into works_on (essn,pno,hours) values('453453453',1,20.00);
insert into works_on (essn,pno,hours) values('453453453',2,20.00);
insert into works_on (essn,pno,hours) values('333445555',2,10.00);
insert into works_on (essn,pno,hours) values('333445555',3,10.00);
insert into works_on (essn,pno,hours) values('333445555',10,10.00);
insert into works_on (essn,pno,hours) values('333445555',20,10.00);
insert into works_on (essn,pno,hours) values('999887777',30,30.00);
insert into works_on (essn,pno,hours) values('999887777',10,10.00);
insert into works_on (essn,pno,hours) values('987987987',10,35.00);
insert into works_on (essn,pno,hours) values('987987987',30,5.00);
insert into works_on (essn,pno,hours) values('987654321',30,20.00);
insert into works_on (essn,pno,hours) values('987654321',20,15.00);
insert into works_on (essn,pno) values('888665555',20);
CREATE TABLE dependent (
    essn text not null,
    dpendent_name text not null,
    sex text not null,
    bdate text not null,
    relationship text not null,
    primary key (essn, dpendent_name),
    foreign key(essn) references employee (ssn)
);
insert into dependent values('333445555','Alice','F','5-Apr-76','DAUGHTER');
insert into dependent values('333445555','Theodore','M','25-Oct-73','SON');
insert into dependent values('333445555','Joy','F','3-May-48','SPOUSE');
insert into dependent values('987654321','Abner','M','29-Feb-32','SPOUSE');
insert into dependent values('123456789','Michael','M','1-Jan-78','SON');
insert into dependent values('123456789','Alice','F','31-Jan-78','Daughter');
insert into dependent values('123456789','Elizabeth','F','5-May-57','SPOUSE');
COMMIT;