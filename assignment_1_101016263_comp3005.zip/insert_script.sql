-- Peter Tran
-- 101016263
BEGIN TRANSACTION;
-- Idempotence is maintained by deleting any previous insertions
DELETE FROM songs WHERE contributor='101016263';
DELETE FROM cds WHERE contributor='101016263';
-- Insert cds
INSERT INTO cds VALUES('101016263CD1','In Rainbows','Radiohead','Nigel Godrich',2007,'101016263');
INSERT INTO cds VALUES('101016263CD2','White Pepper','Ween','Christopher Shaw',2000,'101016263');
-- Insert songs
INSERT INTO songs (title,composer,cd_id,track,contributor) VALUES ('15 Step','Radiohead','101016263CD1',1,'101016263');
INSERT INTO songs (title,composer,cd_id,track,contributor) VALUES ('Bodysnatchers','Radiohead','101016263CD1',2,'101016263');
INSERT INTO songs (title,composer,cd_id,track,contributor) VALUES ('Nude','Radiohead','101016263CD1',3,'101016263');
INSERT INTO songs (title,composer,cd_id,track,contributor) VALUES ('Weird Fishes/Arpeggi','Radiohead','101016263CD1',4,'101016263');
INSERT INTO songs (title,composer,cd_id,track,contributor) VALUES ('All I Need','Radiohead','101016263CD1',5,'101016263');
INSERT INTO songs (title,composer,cd_id,track,contributor) VALUES ('Faust Arp','Radiohead','101016263CD1',6,'101016263');
INSERT INTO songs (title,composer,cd_id,track,contributor) VALUES ('Reckoner','Radiohead','101016263CD1',7,'101016263');
INSERT INTO songs (title,composer,cd_id,track,contributor) VALUES ('House of Cards','Radiohead','101016263CD1',8,'101016263');
INSERT INTO songs (title,composer,cd_id,track,contributor) VALUES ('Jigsaw Falling Into Place','Radiohead','101016263CD1',9,'101016263');
INSERT INTO songs (title,composer,cd_id,track,contributor) VALUES ('Videotape','Radiohead','101016263CD1',10,'101016263');
INSERT INTO songs (title,composer,cd_id,track,contributor) VALUES ('Exactly Where I''m At','Ween','101016263CD2',1,'101016263');
INSERT INTO songs (title,composer,cd_id,track,contributor) VALUES ('Flutes of Chi','Ween','101016263CD2',2,'101016263');
INSERT INTO songs (title,composer,cd_id,track,contributor) VALUES ('Even If You Don''t','Ween','101016263CD2',3,'101016263');
INSERT INTO songs (title,composer,cd_id,track,contributor) VALUES ('Bananas and Blow','Ween','101016263CD2',4,'101016263');
INSERT INTO songs (title,composer,cd_id,track,contributor) VALUES ('Stroker Ace','Ween','101016263CD2',5,'101016263');
INSERT INTO songs (title,composer,cd_id,track,contributor) VALUES ('Ice Castles','Ween','101016263CD2',6,'101016263');
INSERT INTO songs (title,composer,cd_id,track,contributor) VALUES ('Back to Basom','Ween','101016263CD2',7,'101016263');
INSERT INTO songs (title,composer,cd_id,track,contributor) VALUES ('Grobe, The','Ween','101016263CD2',8,'101016263');
INSERT INTO songs (title,composer,cd_id,track,contributor) VALUES ('Pandy Fackler','Ween','101016263CD2',9,'101016263');
INSERT INTO songs (title,composer,cd_id,track,contributor) VALUES ('Stay Forever','Ween','101016263CD2',10,'101016263');
INSERT INTO songs (title,composer,cd_id,track,contributor) VALUES ('Falling Out','Ween','101016263CD2',11,'101016263');
INSERT INTO songs (title,composer,cd_id,track,contributor) VALUES ('She''s Your Baby','Ween','101016263CD2',12,'101016263');
COMMIT;
