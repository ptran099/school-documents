--Without the Tail-Call Optimization
-- fact :: Int -> Int
-- fact 0 = 1
-- fact n = n * (fact (n-1))

fact :: Int -> Int
fact n
  | n < 0 = error "Nope!"
  | otherwise = fact' n 1

fact' :: Int -> Int -> Int
fact' 0 a = a
fact' n a = fact' (n-1) (n*a)
