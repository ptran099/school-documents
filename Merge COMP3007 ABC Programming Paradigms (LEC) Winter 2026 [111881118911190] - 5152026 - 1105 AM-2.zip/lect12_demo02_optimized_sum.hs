sum' :: [Int] -> Int
sum' x = sum'' x 0

sum'' :: [Int] -> Int -> Int
sum'' [] a = a
sum'' (h:t) a = sum'' t (h+a)
