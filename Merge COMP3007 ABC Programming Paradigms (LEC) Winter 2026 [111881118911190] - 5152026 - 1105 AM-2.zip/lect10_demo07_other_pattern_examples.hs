remove :: (Eq a) => a -> [a] -> [a]
remove x [] = []
remove x (h:t)
  | x == h = remove x t
  | otherwise = h : (remove x t)

bar :: Int -> [Char]
bar 0 = ""
bar n = '*' : (bar (n-1))

histogram :: [Int] -> [[Char]]
histogram [] = []
histogram (h:t) = (bar h) : (histogram t)

-- putStr (unlines (histogram [3, 4, 1]))

insertOp :: Int -> [Int] -> [Int]
insertOp x [] = [x]
insertOp x (h:t)
  | x <= h = x:(h:t)
  | otherwise = h:(insertOp x t)
  
insertSort :: [Int] -> [Int]
insertSort [] = []
insertSort (h:t) = insertOp h (insertSort t)

allVowels :: [Char] -> [(Char, Int)]
allVowels x = allVowelsHelper x 0

allVowelsHelper :: [Char] -> Int -> [(Char, Int)]
allVowelsHelper [] _ = []
allVowelsHelper (h:t) i
  | (isVowel h) = (h, i) : allVowelsHelper t (i+1)
  | otherwise = allVowelsHelper t (i+1)
  where isVowel h = (h == 'A' || h == 'E' || h == 'I' || h == 'O' || h == 'U')
  
