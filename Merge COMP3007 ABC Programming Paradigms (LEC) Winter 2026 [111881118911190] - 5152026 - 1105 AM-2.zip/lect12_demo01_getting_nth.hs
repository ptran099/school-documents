getNth :: [a] -> Int -> a

getNth [] _ = error "Nope!"
getNth (h:_) 0 = h

getNth (_:t) n
 | n < 0 = error "Nope!"
 | otherwise = getNth t (n-1)


