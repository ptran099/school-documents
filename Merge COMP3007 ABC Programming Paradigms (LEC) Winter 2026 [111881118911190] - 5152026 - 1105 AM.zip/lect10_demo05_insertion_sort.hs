insertOp :: Int -> [Int] -> [Int]
insertOp x [] = [x]
insertOp x (h:t)
  | x <= h = x:(h:t)
  | otherwise = h:(insertOp x t)
  
insertSort :: [Int] -> [Int]
insertSort [] = []
insertSort (h:t) = insertOp h (insertSort t)