zip' :: [a] -> [b] -> [(a, b)]
zip' (h1:t1) (h2:t2) = (h1, h2) : (zip' t1 t2)
zip' _ _ = []
