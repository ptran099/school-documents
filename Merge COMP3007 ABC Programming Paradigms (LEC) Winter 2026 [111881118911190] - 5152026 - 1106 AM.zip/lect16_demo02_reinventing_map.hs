mapDouble :: [Int] -> [Int]
mapDouble [] = []
mapDouble (h:t) = (2 * h) : mapDouble t

double :: Int -> Int
double x = 2 * x

myMap :: (a -> b) -> [a] -> [b]
myMap f [] = []
myMap f (h:t) = (f h) : (myMap f t)