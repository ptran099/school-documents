filterRemove :: Int -> [Int] -> [Int]
filterRemove x [] = []
filterRemove x (h:t)
  | x == h = filterRemove x t
  | otherwise = h : filterRemove x t

isDiff :: Int -> Int -> Bool
isDiff x y = x /= y

-- *Main> filterRemove 5 [1,0,8,9,3,4,1,0,3,4,5,8,6,1,5,4,3,9,8,5,5,6]
-- [1,0,8,9,3,4,1,0,3,4,8,6,1,4,3,9,8,6]
-- *Main> :t filterRemove
-- filterRemove :: Int -> [Int] -> [Int]
-- *Main> :t isDiff
-- isDiff :: Int -> Int -> Bool
-- *Main> :t isDiff 5
-- isDiff 5 :: Int -> Bool
-- *Main> :t filter
-- filter :: (a -> Bool) -> [a] -> [a]
-- *Main> filter (isDiff 5) [1,0,8,9,3,4,1,0,3,4,5,8,6,1,5,4,3,9,8,5,5,6]
-- [1,0,8,9,3,4,1,0,3,4,8,6,1,4,3,9,8,6]