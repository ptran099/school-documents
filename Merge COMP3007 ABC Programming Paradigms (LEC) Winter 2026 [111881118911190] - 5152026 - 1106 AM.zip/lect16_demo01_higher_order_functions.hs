mapDouble :: [Int] -> [Int]
mapDouble [] = []
mapDouble (h:t) = (2 * h) : mapDouble t

double :: Int -> Int
double x = 2 * x

-- *Main> mapDouble [1,2,3]
-- [2,4,6]

-- *Main> :t mapDouble
-- mapDouble :: [Int] -> [Int]

-- *Main> map double [1,2,3]
-- [2,4,6]

-- *Main> :t map
-- map :: (a -> b) -> [a] -> [b]

-- *Main> :t map double
-- map double :: [Int] -> [Int]