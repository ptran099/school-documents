male(maurice).
male(jeanluc).
male(robert).
male(rene).
female(marie).
female(yvette).
parent(maurice, jeanluc).
parent(yvette, jeanluc).
parent(maurice, robert).
parent(yvette, robert).
parent(robert, rene).
parent(marie, rene).
father(A,B) :- male(A), parent(A,B).
mother(A,B) :- female(A), parent(A,B).
son(A,B) :- male(A), parent(B,A).
daughter(A,B) :- female(A), parent(B,A).
sibling(A,B) :- father(C,A), father(C,B), mother(D,A), mother(D,B), A\=B.
brother(A,B) :- male(A), sibling(A,B).
sister(A,B) :- female(A), sibling(A,B).
aunt(A,B) :- female(A), sibling(A,C), parent(C,B).
uncle(A,B) :- male(A), sibling(A,C), parent(C,B).
nephew(A,B) :- male(A), (uncle(B,A); aunt(B,A)).
niece(A,B) :- female(A), (uncle(B,A); aunt(B,A)).
cousin(A,B) :- parent(C,A), parent(D,B), sibling(C,D).
ancestor(A,B) :- parent(A,B).
ancestor(A,B) :- parent(C,B), ancestor(A,C).
